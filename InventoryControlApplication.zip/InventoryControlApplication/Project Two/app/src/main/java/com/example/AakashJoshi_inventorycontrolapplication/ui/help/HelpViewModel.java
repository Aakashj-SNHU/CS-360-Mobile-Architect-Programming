package com.example.AakashJoshi_inventorycontrolapplication.ui.help;

import androidx.lifecycle.ViewModel;

public class HelpViewModel extends ViewModel {

    public HelpViewModel() { }

}
