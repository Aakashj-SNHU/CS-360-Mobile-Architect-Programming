package com.example.AakashJoshi_inventorycontrolapplication.ui.settings;

import android.content.Context;

import androidx.lifecycle.ViewModel;

import com.example.AakashJoshi_inventorycontrolapplication.data.InventoryDataSource;

public class SettingsViewModel extends ViewModel {

    private InventoryDataSource dataSource;

    public SettingsViewModel() {

    }

    // Initialize the Data Source  Provider
    public void InitializeDataProvider(Context context) {
        dataSource = new InventoryDataSource(context);
    }

    // Used to clear out the data in the inventory table
    public boolean DeleteAllInventoryData() {
        return dataSource.deleteAllInventoryData();
    }

}
